$(document).ready(function () {
  // When the user clicks on a button
  $(".question1").click(function () {
    // Toggle the panel
    $(".img1").toggleClass("up").toggleClass("rotate");
    $(this).next(".panel").slideToggle();
  });
});

$(document).ready(function () {
  // When the user clicks on a button
  $(".question2").click(function () {
    // Toggle the panel
    $(".img2").toggleClass("up").toggleClass("rotate");
    $(this).next(".panel").slideToggle();
  });
});

$(document).ready(function () {
  // When the user clicks on a button
  $(".question3").click(function () {
    // Toggle the panel
    $(".img3").toggleClass("up").toggleClass("rotate");
    $(this).next(".panel").slideToggle();
  });
});

$(document).ready(function () {
  // When the user clicks on a button
  $(".question4").click(function () {
    // Toggle the panel
    $(".img4").toggleClass("up").toggleClass("rotate");
    $(this).next(".panel").slideToggle();
  });
});

$(document).ready(function () {
  // When the user clicks on a button
  $(".question5").click(function () {
    // Toggle the panel
    $(".img5").toggleClass("up").toggleClass("rotate");
    $(this).next(".panel").slideToggle();
  });
});
